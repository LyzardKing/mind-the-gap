name(traffic_rules).
version('1.0.0').
title('Hello world').
author( 'Bob Programmer', 'bob123@programmer.me' ).
download('https://github/bob123/hello.git').